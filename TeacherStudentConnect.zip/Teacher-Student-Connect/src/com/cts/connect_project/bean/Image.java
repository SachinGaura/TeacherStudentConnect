package com.cts.connect_project.bean;

import java.util.Arrays;

public class Image {
private String id;
private byte[] imageData;
private String name;
private String imageFileName;



public Image()
{}



public String getId() {
	return id;
}



public void setId(String id) {
	this.id = id;
}



public byte[] getImageData() {
	return imageData;
}



public void setImageData(byte[] imageData) {
	this.imageData = imageData;
}



public String getName() {
	return name;
}



public void setName(String name) {
	this.name = name;
}



public String getImageFileName() {
	return imageFileName;
}



public void setImageFileName(String imageFileName) {
	this.imageFileName = imageFileName;
}



@Override
public String toString() {
	return "Image [id=" + id + ", imageData=" + Arrays.toString(imageData) + ", name=" + name + ", imageFileName="
			+ imageFileName + "]";
}



public Image(String id, String name, String imageFileName, byte[] imageData) {
	super();
	this.id = id;
	this.imageData = imageData;
	this.name = name;
	this.imageFileName = imageFileName;
}


























}
